# Changelog

## 0.4.0-preview — Claude Starter Kit
- Combined the code foundation with the full product blueprint and Claude master prompt.
- Added detailed data-schema and release roadmap documents.
- Added Termux bootstrap/verification and ZIP packaging scripts.
- Added GitHub Actions workflow for syntax checks, tests and downloadable ZIP artifact.
- Included the approved generated UI concept image for Claude as visual reference.
- Existing tests: 17 passing in the packaging environment.

## 0.5.0 - Android APK wrapper
- Capacitor Android wrapper (config, www bundle script, icon generation).
- `Build Android APK` and `Unzip and apply ZIP` GitHub Actions workflows.
- See BUILD-APK.md.

## 0.5.1 - UI refresh
- New design: cover-first poster cards, shelves on Home, floating bottom navigation with icons.
- Profile is now a hub of sections, with planned-feature slots.
- Settings are organised as categories and sub-categories, driven by `settings-schema.js`.
- New settings: cover size, sort library by, chapter language (now used when opening a title).
- Fixed: the chapter language menu in the title sheet did nothing.
- See docs/EXTENDING-UI.md.

## 0.6.0 - AniList sync
- Sign in with AniList (one-tap app link, or paste a token), import your manga list, and save status changes back.
- Exact-ID matching only, never deletes, asks before adding titles to AniList, skips adult titles while that preference is off.
- Android build registers the `tokyomangalab://anilist-auth` link and bundles the Capacitor App and Browser plugins.
- Local database upgraded to version 2 (new `accountLinks` and `syncLinks` stores; existing data is kept).
- Worker passes `anilistId` and `malId` through (not deployed by this change).
- See docs/ANILIST.md.
