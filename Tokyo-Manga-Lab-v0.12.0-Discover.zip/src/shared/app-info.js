export const APP_VERSION = '0.12.0';
export const APP_NAME = 'Tokyo Manga Lab';
export const REPO_URL = 'https://github.com/tokyo720022-create/tokyo-manga-lab';
export const MANGADEX_URL = 'https://mangadex.org';
